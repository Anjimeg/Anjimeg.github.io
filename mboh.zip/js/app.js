function handleCredentialResponse(response) {
    console.log("Encoded JWT ID token: " + response.credential);
    // Kirim token ini ke server atau simpan di aplikasi untuk autentikasi pengguna
}

function playAlertSound() {
    const alertSound = document.getElementById("alertSound");
    alertSound.play();
}

function updateBatteryStatus(battery) {
    const batteryLevel = Math.round(battery.level * 100);
    document.querySelector('.battery-status').textContent = `BATERAI: ${batteryLevel}%`;
}

function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    document.querySelector('.clock').textContent = `JAM: ${hours}:${minutes}:${seconds}`;
}

function loadURL() {
    const iframe = document.querySelector('.webview');
    const imageContainer = document.querySelector('.image-container');
    const urlInput = document.querySelector('.url-input');

    if (urlInput.value) {
        iframe.src = urlInput.value;
        iframe.style.display = 'block'; 
        imageContainer.style.display = 'none'; 
    }
}

window.addEventListener('load', async () => {
    setInterval(updateClock, 1000);

    if ('getBattery' in navigator) {
        const battery = await navigator.getBattery();
        updateBatteryStatus(battery);
        battery.addEventListener('levelchange', () => updateBatteryStatus(battery));
    }
});